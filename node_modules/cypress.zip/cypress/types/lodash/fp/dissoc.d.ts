import { dissoc } from "../fp";
export = dissoc;
