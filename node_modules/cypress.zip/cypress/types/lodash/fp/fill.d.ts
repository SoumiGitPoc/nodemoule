import { fill } from "../fp";
export = fill;
