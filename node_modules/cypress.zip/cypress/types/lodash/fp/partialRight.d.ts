import { partialRight } from "../fp";
export = partialRight;
