import { curry } from "../fp";
export = curry;
