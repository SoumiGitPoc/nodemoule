import { defaultsAll } from "../fp";
export = defaultsAll;
