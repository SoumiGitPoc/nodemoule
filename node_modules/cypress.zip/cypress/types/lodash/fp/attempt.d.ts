import { attempt } from "../fp";
export = attempt;
