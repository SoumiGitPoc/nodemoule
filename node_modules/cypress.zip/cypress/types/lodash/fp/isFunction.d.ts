import { isFunction } from "../fp";
export = isFunction;
