import { method } from "../fp";
export = method;
