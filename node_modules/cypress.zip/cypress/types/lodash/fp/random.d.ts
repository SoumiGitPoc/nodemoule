import { random } from "../fp";
export = random;
