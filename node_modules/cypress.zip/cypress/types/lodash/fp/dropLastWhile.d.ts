import { dropLastWhile } from "../fp";
export = dropLastWhile;
