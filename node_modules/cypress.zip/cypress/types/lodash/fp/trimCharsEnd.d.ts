import { trimCharsEnd } from "../fp";
export = trimCharsEnd;
