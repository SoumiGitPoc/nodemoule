import { cloneWith } from "../fp";
export = cloneWith;
