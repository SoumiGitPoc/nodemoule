import { curryRight } from "../fp";
export = curryRight;
