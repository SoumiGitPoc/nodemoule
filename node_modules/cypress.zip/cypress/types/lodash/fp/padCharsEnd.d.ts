import { padCharsEnd } from "../fp";
export = padCharsEnd;
