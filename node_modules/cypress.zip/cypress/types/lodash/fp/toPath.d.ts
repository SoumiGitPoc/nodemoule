import { toPath } from "../fp";
export = toPath;
