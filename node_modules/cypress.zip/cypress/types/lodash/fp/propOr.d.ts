import { propOr } from "../fp";
export = propOr;
