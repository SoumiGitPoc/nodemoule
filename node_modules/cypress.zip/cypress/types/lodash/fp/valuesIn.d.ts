import { valuesIn } from "../fp";
export = valuesIn;
