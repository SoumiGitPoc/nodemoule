import { eq } from "../fp";
export = eq;
