import { forOwn } from "../fp";
export = forOwn;
