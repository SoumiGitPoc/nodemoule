import { spread } from "../fp";
export = spread;
