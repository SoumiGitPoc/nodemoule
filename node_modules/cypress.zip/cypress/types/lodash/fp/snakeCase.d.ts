import { snakeCase } from "../fp";
export = snakeCase;
