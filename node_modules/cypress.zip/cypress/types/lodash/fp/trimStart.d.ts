import { trimStart } from "../fp";
export = trimStart;
