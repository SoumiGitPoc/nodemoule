import { toPairs } from "../fp";
export = toPairs;
