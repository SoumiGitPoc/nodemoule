import { identical } from "../fp";
export = identical;
