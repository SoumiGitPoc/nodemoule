import { mergeAll } from "../fp";
export = mergeAll;
