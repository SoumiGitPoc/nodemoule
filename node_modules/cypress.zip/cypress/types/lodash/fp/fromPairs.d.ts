import { fromPairs } from "../fp";
export = fromPairs;
