import { union } from "../fp";
export = union;
