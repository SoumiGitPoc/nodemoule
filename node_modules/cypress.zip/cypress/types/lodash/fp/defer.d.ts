import { defer } from "../fp";
export = defer;
