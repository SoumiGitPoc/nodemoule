import { head } from "../fp";
export = head;
