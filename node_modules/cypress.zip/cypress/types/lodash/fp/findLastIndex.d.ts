import { findLastIndex } from "../fp";
export = findLastIndex;
