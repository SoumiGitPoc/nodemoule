import { where } from "../fp";
export = where;
