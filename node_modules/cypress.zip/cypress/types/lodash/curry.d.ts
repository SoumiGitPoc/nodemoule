import { curry } from "./index";
export = curry;
