import { deburr } from "./index";
export = deburr;
