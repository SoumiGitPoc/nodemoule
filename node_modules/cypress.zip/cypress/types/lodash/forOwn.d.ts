import { forOwn } from "./index";
export = forOwn;
