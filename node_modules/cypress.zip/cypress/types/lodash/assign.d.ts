import { assign } from "./index";
export = assign;
