import { forOwnRight } from "./index";
export = forOwnRight;
