import { flattenDepth } from "./index";
export = flattenDepth;
